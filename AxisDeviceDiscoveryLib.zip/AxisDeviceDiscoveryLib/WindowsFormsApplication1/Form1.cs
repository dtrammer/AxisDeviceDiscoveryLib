﻿using System;
using System.Windows.Forms;
using AxisDeviceDiscoveryLib.core.services;
using AxisDeviceDiscoveryLib.core.types;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        TreeNode _tvMainNode;

        public Form1()
        {
            InitializeComponent();
            _tvMainNode = new TreeNode("Results");
            this.tvResults.Nodes.Add(_tvMainNode);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int TimeOut = 5000;
            _tvMainNode.Nodes.Clear();
            DiscoveryService service = new DiscoveryService((interfaces) =>
            {
                this.Invoke(new Action(() =>
                {

                    foreach (networkInterface ni in interfaces)
                    {

                        TreeNode InterfaceNode = new TreeNode("Network interface " + ni.Lanid + " - IP : " + ni.IPAddress + " - Datalink : " + ni.type + " - devices discovered : " + ni.DiscoveredDevices.Count);
                        TreeNode DeviceNode;
                        foreach (deviceNetworkInfo dn in ni.DiscoveredDevices)
                        {
                            DeviceNode = new TreeNode(dn.IPaddress.ToString() + " - " + dn.MACAddress + " - " + dn.Model);
                                DeviceNode.Nodes.Add(new TreeNode("ONVIF Service url : " + dn.ONVIFXAddress));
                                DeviceNode.Nodes.Add(new TreeNode("UPNP Service url : " + dn.UPNPServiceAddress));
                            InterfaceNode.Nodes.Add(DeviceNode);
                        }

                        _tvMainNode.Nodes.Add(InterfaceNode);


                    }
                }));
            });

            service.Search(TimeOut);
        }
    }
    

}
